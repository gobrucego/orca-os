# Awesome AI System Prompts

So far collection include system prompts for:

- Augment Code (latest 2025-04-09)
- BlackboxAI (latest 2025-04-08)
- Bolt.new
- ChatGPT (latest 2025-04-07)
- Claude
- Claude Code (latest 2025-04-09)
- Cline
- Loveable
- Manus
- MetaAI
- Notte (latest 2025-04-09)
- perplexity.ai (latest 2025-04-09)
- same.new (latest 2025-04-09)
- v0 (latest 2025-04-09)

I'm looking for inspirations how to improve [Harpagan](https://harpagan.com).

## Contact

Connect with me on [LinkedIn](https://www.linkedin.com/in/dontriskit/).

## Sources

- MetaAI LLama4: Zibri, u/Robert__Sinclair
